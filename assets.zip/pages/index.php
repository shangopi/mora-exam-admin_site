<?php include 'header.php';?>
<br><br><br><br><br><br>
<div  class="container">
<img src="https://p.kindpng.com/picc/s/270-2708235_new-content-coming-soon-web-page-is-under.png" alt="" srcset="">
</div>
<br><br><br><br><br><br>
<?php include 'footer.php';?>

<script>
    $(document).ready(function () {


$("#title123").text("Dashboard ");
$("#n1").addClass("active");

    })
</script>