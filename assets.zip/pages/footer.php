<footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="http://www.moraexams.com">
                  Website
                </a>
              </li>
              <li>
                <a href="https://www.facebook.com/moraexams">
                  Facebook
                </a>
              </li>
              <li>
                <a href="https://www.linkedin.com/company/mora-exams/">
                  Linked In
                </a>
              </li>
              <li>
                <a href="https://twitter.com/MoraExams">
                  Twitter
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script> | Copy rights reserved to <i class="material-icons">favorite</i> 
            <a href="http://www.moraetamils.com" target="_blank">MORA E-TAMILS</a>
          </div>
        </div>
      </footer>
    </div>
  </div>
</body>

</html>